"""
Created on Wed Feb  3 12:36:09 2016

@author: spencer.davison
"""

import plotly
import plotly.plotly as py
from plotly.graph_objs import *
import plotly.tools as tls
import numpy as np


py.sign_in("sdavison88","ls005fl7r5")

#steam_ids = tls.get_credentials_file()['stream_ids']

#stream_id=stream_ids[0]

stream=Stream(token='81iryp10uc',
              maxpoints=20
              )

trace1=Scatter(
    x=[],
    y=[],
    stream=stream,
    mode ='lines',
    line = dict(
        color='rgb(226,0,116)'
        )
        )

data=Data([trace1])

# Add title to layout object
layout = Layout(
                font=dict(family="Tele-GroteskNor",color="#F0F0F0"),
                xaxis=dict(linecolor="#898989",gridcolor="#898989"),
                yaxis=dict(linecolor="#898989",gridcolor="#898989"),
                paper_bgcolor='rgb(53,53,53)',
                plot_bgcolor='rgb(53,53,53)',
                margin=dict(b=40,l=40,r=40,t=40),
                hidesources=True)

# Make a figure object
fig = Figure(data=data, layout=layout)

# (@) Send fig to Plotly, initialize streaming plot, open new tab
unique_url = py.plot(fig, filename='activeusers')

s=py.Stream('81iryp10uc')
 

from googleapiclient.discovery import build
from oauth2client.client import SignedJwtAssertionCredentials
import httplib2
import datetime
import time
    

scope = ['https://www.googleapis.com/auth/analytics.readonly']
service_account_email = 't-mobile@t-mobile-1203.iam.gserviceaccount.com'
key_file_location = '/Users/spencer.davison/Desktop/T-Mobile/Key.p12'
api_name ='analytics'
api_version ='v3'
gametrics ="rt:activeusers"
f = open(key_file_location, 'rb')
key = f.read()
f.close()

credentials = SignedJwtAssertionCredentials(service_account_email, key,scope=scope)

http = credentials.authorize(httplib2.Http())
service = build(api_name, api_version, http=http)

  
ga_web = service.data().realtime().get(ids='ga:113841332',metrics=gametrics).execute()
ga_amoe = service.data().realtime().get(ids='ga:113865394',metrics=gametrics).execute()
ga_ios = service.data().realtime().get(ids='ga:115431021',metrics=gametrics).execute()
ga_andriod = service.data().realtime().get(ids='ga:115372090',metrics=gametrics).execute()

web_rows=[]
amoe_rows=[]
ios_rows=[]
andriod_rows=[]

   #write header row
web_rows=ga_web.get('rows')
amoe_rows = ga_amoe.get('rows')
ios_rows = ga_ios.get('rows')
andriod_rows = ga_andriod.get('rows')

activeusers = 0

if web_rows:
     if web_rows[0]:
      activeusers += int(web_rows[0][0])
if amoe_rows:
       if amoe_rows[0]:
        activeusers  += int(amoe_rows[0][0])
if ios_rows:
       if ios_rows[0]:
        activeusers  += int(ios_rows[0][0])
if andriod_rows:
    if andriod_rows[0]:
     activeusers  += int(andriod_rows[0][0])

s.open()
 # number of points to be plotted

# Delay start of stream by 5 sec (time to switch tabs)
time.sleep(1)

while True:   # add to counter

    ga_web = service.data().realtime().get(ids='ga:113841332',metrics=gametrics).execute()
    ga_amoe = service.data().realtime().get(ids='ga:113865394',metrics=gametrics).execute()
    ga_ios = service.data().realtime().get(ids='ga:115431021',metrics=gametrics).execute()
    ga_andriod = service.data().realtime().get(ids='ga:115372090',metrics=gametrics).execute()

    web_rows=[]
    amoe_rows=[]
    ios_rows=[]
    andriod_rows=[]

   #write header row
    web_rows=ga_web.get('rows')
    amoe_rows = ga_amoe.get('rows')
    ios_rows = ga_ios.get('rows')
    andriod_rows = ga_andriod.get('rows')
    
    activeusers = 0

    if web_rows:
      if web_rows[0]:
       activeusers += int(web_rows[0][0])
    if amoe_rows:
        if amoe_rows[0]:
         activeusers  += int(amoe_rows[0][0])
    if ios_rows:
        if ios_rows[0]:
         activeusers  += int(ios_rows[0][0])
    if andriod_rows:
     if andriod_rows[0]:
      activeusers  += int(andriod_rows[0][0])

    # Current time on x-axis, random numbers on y-axis
    x = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')
    y = activeusers

    # (-) Both x and y are numbers (i.e. not lists nor arrays)

    # (@) write to Plotly stream!
    s.write(dict(x=x, y=y))
  
    time.sleep(8)

    # (!) Write numbers to stream to append current data on plot,
    #     write lists to overwrite existing data on plot (more in 7.2).

 # (!) plot a point every 80 ms, for smoother plotting

# (@) Close the stream when done plotting
s.close()